import subprocess


def run_command(command: str, timeout: int = 15):
    try:
        completed = subprocess.run(
            command,
            shell=True,
            text=True,
            capture_output=True,
            timeout=timeout,
        )
        output = (completed.stdout or "") + (completed.stderr or "")
        return completed.returncode == 0, output.strip()
    except subprocess.TimeoutExpired:
        return False, f"Comanda a expirat: {command}"
    except Exception as exc:
        return False, str(exc)
